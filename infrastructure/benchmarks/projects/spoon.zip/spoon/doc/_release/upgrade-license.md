# Upgrade License

In order to upgrade license, use `mvn license:format` after having change `LICENSE-short.txt` from the root.

For more information about the plugin we are using, see: http://code.mycila.com/license-maven-plugin/.