---
title: Maven
tags: [usage]
keywords: maven, central, usage, java, plugin
---

The main documentation of the Spoon Maven plugin is in the README of <https://github.com/SpoonLabs/spoon-maven-plugin>. 

Pull requests on this documentation should be done on <https://github.com/SpoonLabs/spoon-maven-plugin> and not here.
