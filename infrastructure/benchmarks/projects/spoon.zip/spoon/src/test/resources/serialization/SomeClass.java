public class SomeClass {
	public int a;
}