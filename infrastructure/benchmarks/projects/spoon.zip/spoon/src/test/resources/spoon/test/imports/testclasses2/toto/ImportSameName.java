package spoon.test.imports.testclasses2.toto;

/**
 * Created by urli on 02/02/2017.
 */
public class ImportSameName {
}
