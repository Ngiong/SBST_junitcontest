package snippet.test.resources;

public class SnippetResources {

    public static void staticMethod() {
        SnippetResources s = new SnippetResources();
    }

    public void method(int a) {
        System.out.println(a);
    }

}
