package fr.simplemodule.pack;

public class SimpleClass {

	public static void main(String[] args) {
		System.out.println("Hello world!");
	}
}