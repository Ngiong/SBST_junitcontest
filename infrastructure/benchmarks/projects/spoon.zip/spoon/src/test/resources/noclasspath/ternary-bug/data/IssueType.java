package de.uni_bremen.st.quide.persistence.data;

public enum IssueType {
}
