package spoon.test.prettyprinter;

public class DefaultPrettyPrinterDependency {

}
