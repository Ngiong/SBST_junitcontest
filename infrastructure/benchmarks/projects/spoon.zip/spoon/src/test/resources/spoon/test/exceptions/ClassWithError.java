package spoon.test.exceptions;

class ClassWithError {
	void foo() {
		int x = KJHIZGR.f; // this is the error
	}
}
