package spoon.test.same;

public class A {

    public B createB() {
        return new B();
    }
}
