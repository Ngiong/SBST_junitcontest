public class A {

	int a;

	int func(int x, int y) {
		return x + y;
	}
}
