package my.pack;

public class IsoEncoding {

    private String entr�e;
    public IsoEncoding(String maCha�ne) {
        this.entr�e = maCha�ne;
    }

    private String r�cup�rerUneEntr�e() {
        return this.entr�e;
    }
}