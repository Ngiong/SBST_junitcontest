package spoon.test.processing.testclasses.test;

import spoon.test.processing.testclasses.test.sub.A;

public class B {
    private A a = new A();
}
