package fr.acme;

import org.myorganization.pack.MyAbstractClass;

public class MyClass extends MyAbstractClass {
	public MyClass(String name) {
		super(name);
	}

	public void method() {

	}
}