package spoon.test.processing.testclasses.test.sub;

public class A {
}
