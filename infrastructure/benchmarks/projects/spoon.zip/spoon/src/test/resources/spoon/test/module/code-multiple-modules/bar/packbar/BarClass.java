package packbar;

public class BarClass {

}