package spoontest;

public interface IFoo
{
	
}
