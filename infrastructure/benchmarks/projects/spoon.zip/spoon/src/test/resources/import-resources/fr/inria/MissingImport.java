
package fr.inria;
import fr.inria.internal.Abcd;

public class MissingImport {

    private final Abcd abcd = new Abcd();
}
