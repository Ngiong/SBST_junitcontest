
public class Toto extends Truc {
	String t = machin().field;
}