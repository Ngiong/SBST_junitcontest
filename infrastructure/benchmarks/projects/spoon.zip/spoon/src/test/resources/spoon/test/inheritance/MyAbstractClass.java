package org.myorganization.pack;

import org.myorganization.MyInterface;

public abstract class MyAbstractClass implements MyInterface {
	public MyAbstractClass(String name) {

	}
}