public class Test {
    int field = 42;
}