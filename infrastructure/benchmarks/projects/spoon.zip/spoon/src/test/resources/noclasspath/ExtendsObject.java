package test;

public class ExtendsObject {
	public void oneMethod() {

	}

	@Override
	public String toString() {
		return "Hello";
	}
}
