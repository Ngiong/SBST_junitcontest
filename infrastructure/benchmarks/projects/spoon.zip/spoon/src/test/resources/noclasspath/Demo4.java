
import example.A;
import example.B;

public class Demo4 extends B {
	A a;
	private void doSomething() {
		a.foo().bar(b);
	}
}