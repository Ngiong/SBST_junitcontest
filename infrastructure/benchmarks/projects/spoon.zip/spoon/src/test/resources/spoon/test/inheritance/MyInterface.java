package org.myorganization;

public interface MyInterface {
	void method();
}