public class C {

	float val;
}
