package spoon.test.reference;

public class ReferencedClass {

	public ReferencedClass() {
		name = "instance";
		ID = 1913810;
	}
	
	protected String name;
	protected int ID;
}
