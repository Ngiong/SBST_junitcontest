class Foo4 {
	static {
		System.out.println("fooo");
	}
}