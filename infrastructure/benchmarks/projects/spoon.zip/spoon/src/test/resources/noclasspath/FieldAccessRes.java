public class FieldAccessRes {

	void method() {
		A a = new A();
		a.l = 5;
	}

}