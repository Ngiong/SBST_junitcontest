public class Demo5 {
	public void foo() {
		A.B b = new A.B<C>() {
			D d = new D();
		};
	}
}