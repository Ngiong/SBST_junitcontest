package jdtimportbuilder;

import static jdtimportbuilder.itf.DumbItf.*;

public class ItfImport {

    String s = MYSTRING;
    int i = anotherStaticMethod();
}
