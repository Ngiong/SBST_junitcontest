package packfoo;

public class FooClass {

}