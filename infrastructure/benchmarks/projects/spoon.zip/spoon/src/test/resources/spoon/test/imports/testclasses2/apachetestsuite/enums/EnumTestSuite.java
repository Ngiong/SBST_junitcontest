package spoon.test.imports.testclasses2.apachetestsuite.enums;

import junit.framework.Test;
import junit.framework.TestCase;

/**
 * Created by urli on 22/06/2017.
 */
public class EnumTestSuite extends TestCase {
    public static Test suite() {
        return null;
    }
}
