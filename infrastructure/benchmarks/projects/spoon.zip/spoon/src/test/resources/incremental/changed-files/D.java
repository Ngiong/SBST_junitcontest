public class D {

	int a;
	String b;

	void func() {
	}
}
