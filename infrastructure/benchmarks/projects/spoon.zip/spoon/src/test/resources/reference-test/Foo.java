public class Foo {
  KJHKY l;
}

