package spoon.test.fieldaccesses.testclasses.internal;

public abstract class Foo extends Bar.Inner {
	class Test {
		class Test2 {

		}
	}
}
