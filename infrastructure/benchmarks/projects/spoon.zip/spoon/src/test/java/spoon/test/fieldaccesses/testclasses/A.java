package spoon.test.fieldaccesses.testclasses;

public class A {
	public static int myField = 3;
	public static final int myfinalField = 3;
}