/*
 * comment1
 */

// comment2
/**
 * Comment3
 */
@java.lang.Deprecated
package spoon.test.comment.testclasses;
