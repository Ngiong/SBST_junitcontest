package spoon.test.generics.testclasses;

public interface ITacos<T> {
}
