package spoon.test.generics.testclasses;

public class Lunch<A,B> {
	<C> void eatMe(A paramA, B paramB, C paramC){}
}
