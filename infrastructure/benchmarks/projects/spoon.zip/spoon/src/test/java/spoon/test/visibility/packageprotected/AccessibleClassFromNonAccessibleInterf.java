package spoon.test.visibility.packageprotected;

public class AccessibleClassFromNonAccessibleInterf implements NonAccessibleInterf {

	public void method(NonAccessibleInterf tmp) {
	}
}
