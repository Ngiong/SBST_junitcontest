package spoon.test.position.testclasses;

public enum SomeEnum {
	X {
		void m() {};
	};
	
	abstract void m();
}