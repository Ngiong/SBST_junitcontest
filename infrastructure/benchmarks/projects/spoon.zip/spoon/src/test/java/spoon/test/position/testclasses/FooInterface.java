package spoon.test.position.testclasses;

import spoon.test.annotation.testclasses.InnerAnnot;

@Deprecated
@InnerAnnot(value="machin")
public interface FooInterface {

}