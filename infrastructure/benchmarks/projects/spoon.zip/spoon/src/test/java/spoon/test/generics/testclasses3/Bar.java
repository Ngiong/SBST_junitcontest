package spoon.test.generics.testclasses3;

public interface Bar<I, O> {
	O transform(I input);
}
