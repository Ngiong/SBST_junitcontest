package spoon.test.fieldaccesses.testclasses;

public class Kuu {
	public void m(Mole.Delicious delicious) {
	}
}
