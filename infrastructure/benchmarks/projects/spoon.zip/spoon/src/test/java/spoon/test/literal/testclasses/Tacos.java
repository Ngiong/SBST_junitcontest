package spoon.test.literal.testclasses;

public class Tacos {
	int a = 0;
	byte b = 0x0;
	float c = 0f;
	long d = 0l;
	double e = 0d;
	char f = '0';
	String g = "0";
	Object h = null;
	boolean i = true;
}
