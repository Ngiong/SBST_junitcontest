package spoon.test.change.testclasses;

public class SubjectOfChange {

	public SubjectOfChange() {
	}
	
	int someField = 1;
}
