package spoon.test.position.testclasses;

public abstract class FooAbstractMethod {

	public abstract void m(final int parm1);
}