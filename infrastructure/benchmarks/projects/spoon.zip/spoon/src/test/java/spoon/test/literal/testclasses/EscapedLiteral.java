package spoon.test.literal.testclasses;

public class EscapedLiteral {

  char c1 = '\0';

  char c2 = '\7';

  char c3 = '\77';

  char c4 = '\177';

  char c5 = '\277';

  char c6 = '\377';

  char c7 = '\u0000';

  char c8 = '\u0001';

  char c9 = '\u0002';
}