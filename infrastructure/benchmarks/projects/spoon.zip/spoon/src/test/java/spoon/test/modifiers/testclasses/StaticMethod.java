package spoon.test.modifiers.testclasses;

public class StaticMethod {
    public static int maMethod() {
        return 42;
    }

    private static int anotherMethod() {
        return 42;
    }
}
