package spoon.test.executable.testclasses;

import java.io.IOException;

/**
 * Created by nicolas on 25/03/2015.
 */
public interface MyIntf {

	public void myMethod() throws IOException;
}
