package spoon.test.comment.testclasses;

// comment 1
// comment 2
public class Comment1 {

    public void code_1()
    {
        try {		}
        // A
        // B
        catch (Exception ex)
        {		}
    }

}
