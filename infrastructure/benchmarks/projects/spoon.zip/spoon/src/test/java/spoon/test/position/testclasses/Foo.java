package spoon.test.position.testclasses;

public class Foo {

}