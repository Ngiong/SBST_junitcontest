package spoon.test.visibility.testclasses.internal;

public class Double {
	public static String toHexString(double d) {
		return "";
	}

	public static java.lang.Double aMethodNotInJavaLangDoubleClass(String param1, String param2) {
		return 0.0;
	}

	public void aMethodNotStatic() {
	}
}
