package spoon.test.comment.testclasses;

/**
 * @author there is tag, but there is no comment
 */
public class JavaDocEmptyCommentAndTags {

	//check empty javadoc too
	/**
	 */
	public void m() {

	}
}