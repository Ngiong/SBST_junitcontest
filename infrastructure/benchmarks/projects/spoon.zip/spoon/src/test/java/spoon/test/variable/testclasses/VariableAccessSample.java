package spoon.test.variable.testclasses;

public class VariableAccessSample {

	public void method() {
		String s = "tacos";
		System.out.println(s);
		int i = 3;
		i = 4;
	}
}
