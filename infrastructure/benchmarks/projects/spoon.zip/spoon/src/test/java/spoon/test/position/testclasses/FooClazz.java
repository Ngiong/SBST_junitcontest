package spoon.test.position.testclasses;

@Deprecated
public class FooClazz {

}