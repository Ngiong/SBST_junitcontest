package spoon.test.generics.testclasses3;

public class ClassThatDefinesANewTypeArgument<T> {
	void foo(T t){}
}
