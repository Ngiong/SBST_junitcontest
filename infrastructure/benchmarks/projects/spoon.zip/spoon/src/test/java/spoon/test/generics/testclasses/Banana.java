package spoon.test.generics.testclasses;

import java.util.AbstractList;

public class Banana<T> {
	abstract class Vitamins extends AbstractList<T> {
	}
}
