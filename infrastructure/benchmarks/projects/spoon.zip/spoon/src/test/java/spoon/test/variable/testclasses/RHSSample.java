package spoon.test.variable.testclasses;

// contains four RHS assignments
public class RHSSample {
	String s1 = "foo";
	public void method() {
		String bar = "tacos";
		int i;
		i = 4;
	}
}
