package spoon.test.method_overriding.testclasses2;

public interface ObjectInterface {
    void doSomething();
    boolean equals(Object other);
}