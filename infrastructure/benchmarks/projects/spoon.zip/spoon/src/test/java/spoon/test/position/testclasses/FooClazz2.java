package spoon.test.position.testclasses;

/** getLine starts at api documentation */
public class FooClazz2 {}
