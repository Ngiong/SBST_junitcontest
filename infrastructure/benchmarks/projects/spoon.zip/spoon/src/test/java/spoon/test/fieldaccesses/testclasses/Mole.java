package spoon.test.fieldaccesses.testclasses;

class Mole {
	public class Delicious {
	}
}
