package spoon.test.comment.testclasses;

public class TestClassWithComments {

    
// ------------------------------------ //
// test / test test     //
// ------------------------------------ //

    /**
     * test2
     */   
    public interface testInterface {
        /**
         * test3
         */
        public void mytest(short a, short b);
    }
    private static class myInterface implements testInterface {
        public void mytest(short a, short b){
            
        }
    }
    
}//end class test