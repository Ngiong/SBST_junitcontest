package spoon.test.method_overriding.testclasses;

public interface IA {

}
