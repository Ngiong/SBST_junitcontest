package spoon.test.variable.testclasses;

public class StackedAssignmentSample {

	public void method() {
		int i,j,k = 3;
		i = j = k = 4;
	}
}
