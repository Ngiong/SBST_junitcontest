package spoon.test.position.testclasses;

/*c1*/
//lc1
public /*c2*/
//lc2 /*
class 
// */
/*c3 class // */
FooClazzWithComments {

}