package spoon.test.visibility.packageprotected;

interface NonAccessibleInterf {
}
