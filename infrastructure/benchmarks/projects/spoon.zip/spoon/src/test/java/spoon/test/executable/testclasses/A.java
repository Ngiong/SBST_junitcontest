package spoon.test.executable.testclasses;

public class A {
	public static int getInt1() {
		return 1;
	}

	public final static int getInt2() {
		return 2;
	}

	public final int getInt3() {
		return 3;
	}

	public int getInt4() {
		return 4;
	}
}