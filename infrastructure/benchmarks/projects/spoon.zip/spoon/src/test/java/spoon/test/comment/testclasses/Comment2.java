package spoon.test.comment.testclasses;

public class Comment2 {

    // C
    @interface Code_2{}

    public void code_3()
    {
        int[] myArray = {
                3, 5	// D
        };
    }
}
