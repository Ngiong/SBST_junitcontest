package spoon.test.position.testclasses; public class TestSimpleClass {
    public int x;
    public int y;
    public int z;
}
