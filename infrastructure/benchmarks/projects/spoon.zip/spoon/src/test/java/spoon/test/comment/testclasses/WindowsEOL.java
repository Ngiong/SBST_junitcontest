package spoon.test.comment.testclasses;

/**
 * This file contains MS Windows EOL.
 * It is here to test whether comments are printed well
 * in this case
 * 
 * @author pvojtechovsky
 */
public class WindowsEOL {
}
