/*
 * Top File
 * Line 2
 */
/* package declaration comments*/
package spoon.test.position.testclasses;

//import comment
import java.util.ArrayList;


public class CompilationUnitComments<T extends ArrayList<T>> {
}
/*
 * Bottom File
 */