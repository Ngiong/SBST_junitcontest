package spoon.test.comment.testclasses;

/**
 * A short description without a proper end
 */
public class OtherJavaDoc {
}
