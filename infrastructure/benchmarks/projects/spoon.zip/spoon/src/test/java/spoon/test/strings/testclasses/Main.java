package spoon.test.strings.testclasses;

public class Main {

	public static void main(String[] args) {

		System.out.println("a"+"b");
		System.out.println("a\n"+"b\n");
		System.out.println("ab");
		System.out.println("c");
		System.out.println("a\nb\n");
		System.out.println("c\n");
		System.out.println("c\n"+"test");
		System.out.println("c"+"test".toString());

	}

}
