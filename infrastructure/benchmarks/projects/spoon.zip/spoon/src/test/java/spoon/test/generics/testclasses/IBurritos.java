package spoon.test.generics.testclasses;

public interface IBurritos<K, V> {
	IBurritos<K, V> make();
}
