package spoon.test.executable.testclasses;

public class AnonymousExecutableSample {
	{
	}

	static {
	}
}
